# MySQL on RDS Example

This is an example of how to use the [mysql module](/modules/mysql).

## Quick start

1. Open `variables.tf` and update variables as necessary.
2. Run `tofu init`.
3. Run `tofu apply`.
4. When you're done testing, run `tofu destroy`.