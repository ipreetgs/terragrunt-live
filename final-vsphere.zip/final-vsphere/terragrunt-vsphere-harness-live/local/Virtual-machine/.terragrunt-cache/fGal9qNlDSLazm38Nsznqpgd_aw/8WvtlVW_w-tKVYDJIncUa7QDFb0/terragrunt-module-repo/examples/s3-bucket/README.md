# S3 bucket example

This is an example of how to use the [s3-bucket module](/modules/s3-bucket).

## Quick start

1. Open `variables.tf` and update variables as necessary.
2. Run `tofu init`.
3. Run `tofu apply`.
4. When you're done testing, run `tofu destroy`.